## Installation

1. Copy the entire quiz/ folder into your modules directory.

2. Log in to your site as an administrator, and go to the Administer >> Site
   building >> Modules section. Enable both the Quiz module, the Quiz Question
   module and at least one question type module (for example, Multichoice).

## How to create a quiz

1. Create a basic quiz by going to Create content >> Quiz. You will have
   the opportunity to set many options if you would like.

2. Finally, add questions to the quiz by clicking the "Quiz" tab and then
   "Manage questions". Here you can create a new question, or use the question
   bank to add a previously used question.

3. After adding questions, click the "Take" tab to take the Quiz!
