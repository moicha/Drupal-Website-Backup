## Upgrading from 7.x-4.x to 7.x-5.0

If you do not have any custom question modules, an upgrade to 5.x is easy.

1. Backup your database
2. Delete the old Quiz module folder
3. Copy the new Quiz module folder into place
4. Run update.php
5. Verify that existing quizzes work
6. Verify that existing results work
7. Done!

If you encounter any errors during update, please post them to
https://www.drupal.org/project/issues/quiz
